import Header from './Header';
import React from 'react'

import "./App.css"

export default function Title() {
  return (
    <>
    <div>
<Header />
    </div>
    <div class="t">
    <span class="text1">Welcome to HEXAWARE</span>
    <span class="text2">LEAVE MANAGEMENT SYSTEM</span>
    </div>
    </>
  )
}
